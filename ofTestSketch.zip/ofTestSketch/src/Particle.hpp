//
//  Particle.hpp
//  ofTestSketch
//
//  Created by Linus on 07/02/17.
//
//

#ifndef Particle_hpp
#define Particle_hpp

#include <stdio.h>
#include "ofMain.h"

class Particle
{
    public:
        Particle();
        Particle(float x, float y);
        ~Particle();
    
        void Draw();
        void Update();
    
    private:
        ofVec2f _position;
        float   _radius;
        
    
};

#endif /* Particle_hpp */
