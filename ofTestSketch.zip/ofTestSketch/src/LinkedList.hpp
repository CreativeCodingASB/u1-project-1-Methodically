//
//  LinkedList.hpp
//  ofTestSketch
//
//  Created by Linus on 07/02/17.
//
//

#ifndef LinkedList_hpp
#define LinkedList_hpp

#include <stdio.h>
#include "Node.hpp"
#include "Particle.hpp"

class LinkedList
{
    public:
        LinkedList();
        ~LinkedList();
    
        void AddParticle();
        void Remove(int index);
        void Remove(Particle &p);
        Particle& Get(int i);
    
        int  GetLength() { return _length; }
    
    private:
        int   _length;
        Node* _firstNode;
};

#endif /* LinkedList_hpp */
