//
//  Node.cpp
//  emptyExample
//
//  Created by Rana Lulla on 10/2/2017.
//
//

#include "Node.hpp"

Node::Node(float x, float y)
{
    _nextNode = nullptr;
    _data = new Circle(x, y);
}
Node::~Node()
{
    _nextNode = NULL;
    delete _nextNode;
    delete _data;
}
Node *Node::GetNext()
{
    return _nextNode;
}
Circle& Node::GetData()
{
    return *_data;
}
Circle Node::GetCopy()
{
    return *_data;
}
void Node::SetNext(Node* &n)
{
    _nextNode = n;
    return;
}
void Node::SetData(Circle &c)
{
    Circle* garbage = _data;
    _data = &c;
    delete garbage;
}
