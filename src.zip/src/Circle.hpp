//
//  Circle.hpp
//  emptyExample
//
//  Created by Rana Lulla on 14/2/2017.
//
//

#ifndef Circle_hpp
#define Circle_hpp

#include <stdio.h>
#include "ofMain.h"

class Circle
{
    public:
        Circle(float x, float y);
        void Draw();
        void Update(float x, float y);
    private:
        ofVec2f pos;
};

#endif /* Circle_hpp */
