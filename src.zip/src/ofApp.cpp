#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup()
{
    for(int i=0; i<50; i++)
    {
    circles.AddCircle(mouseX, mouseY);
    }
}
void ofApp::update()
{
    for(int i = 1; i < circles.GetLength(); i++)
    {
        circles.Get(i).Update(mouseX, mouseY);
    }
}
void ofApp::draw()
{
    ofBackground(0, 0, 0);
    for(int i = 1; i < circles.GetLength(); i++)
    {
        circles.Get(i).Draw();
    }
}
void ofApp::mousePressed(int x, int y, int button)
{
    circles.Remove(1);
}
