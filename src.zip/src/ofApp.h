#pragma once

#include "ofMain.h"
#include "Circle.hpp"
#include "LinkedList.hpp"

class ofApp : public ofBaseApp{
	public:
		void setup();
		void update();
		void draw();
		void mousePressed(int x, int y, int button);

//      void mouseMoved(int x, int y);
//		void keyPressed(int key);
//		void keyReleased(int key);
//		void mouseDragged(int x, int y, int button);
//		void mouseReleased(int x, int y, int button);
//		void mouseEntered(int x, int y);
//		void mouseExited(int x, int y);
//		void windowResized(int w, int h);
//		void dragEvent(ofDragInfo dragInfo);
//		void gotMessage(ofMessage msg);
    
    private:
        LinkedList circles;
};
