//
//  LinkedList.hpp
//  emptyExample
//
//  Created by Rana Lulla on 20/2/2017.
//
//

#ifndef LinkedList_hpp
#define LinkedList_hpp

#include <stdio.h>
#include "Node.hpp"
#include "Circle.hpp"

class LinkedList
{
    public:
        LinkedList();
        ~LinkedList();
        void AddCircle(float x, float y);
        void Remove(int index);
        void Remove(Circle &c);
        Circle& Get(int i);
    
        int GetLength() { return _length; }
    
    private:
        int _length;
        Node* _firstNode;
};

#endif /* LinkedList_hpp */
