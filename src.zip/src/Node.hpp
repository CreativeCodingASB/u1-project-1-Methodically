//
//  Node.hpp
//  emptyExample
//
//  Created by Rana Lulla on 10/2/2017.
//
//

#ifndef Node_hpp
#define Node_hpp

#include <stdio.h>
#include "Circle.hpp"

class Node
{
    public:
        Node(float x, float y);
        ~Node();
    
        void SetNext(Node* &n);
        void SetData(Circle& c);
        Node* GetNext();
        Circle& GetData();
        Circle GetCopy();
        void operator = (const Node& n);
    
    private:
        Circle* _data;
        Node* _nextNode;
};

#endif /* Node_hpp */
