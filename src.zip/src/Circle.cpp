//
//  Circle.cpp
//  emptyExample
//
//  Created by Rana Lulla on 14/2/2017.
//
//

#include "Circle.hpp"

Circle::Circle(float x, float y)
{
    pos.set(x, y);
}
void Circle::Draw()
{
    ofSetColor(ofRandom(200, 256), ofRandom(200, 256), ofRandom(200, 256));
    ofDrawEllipse(pos.x, pos.y, 10, 10);
}
void Circle::Update(float x, float y)
{
    ofVec2f dir;
    if(ofRandom(0, 2)<1)
    {
        dir.x = x - pos.x;
        dir.y = y - pos.y;
    }
    else
    {
        dir.x += ofRandom(-10, 10);
        dir.y += ofRandom(-10, 10);
    }
    dir.normalize();
    pos+=dir*10;
}
